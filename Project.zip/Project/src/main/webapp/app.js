(function () {
    angular
        .module("BookMyShow", ["ngRoute", "ngResource", "textAngular"]);
})();