package com.bookmyshow.repositories;

import org.springframework.data.repository.CrudRepository;

import com.bookmyshow.models.Theatre;

public interface TheatreRepository extends CrudRepository<Theatre, Integer>{


}